---
protocol: fcop
version: 1
kind: spec
sender: TEMPLATE
recipient: TEAM
team: qa-team
doc_id: TEAM-ROLES
updated_at: 2026-05-12
---

# qa-team 角色分工

## 团队概览

- 团队:`qa-team`
- leader:`LEAD-QA`
- 角色:`LEAD-QA`、`TESTER`、`AUTO-TESTER`、`PERF-TESTER`
- ADMIN:真人管理员,不进 `roles/`

## LEAD-QA

### 负责

- 接收 `ADMIN` 测试目标、质量门槛、优先级
- 制定测试策略、拆分任务给功能/自动化/性能三个方向
- 跟踪各方向进度,汇总结论
- 做最终发布/打回的质量决策建议
- 维护测试计划、风险矩阵、共享测试资产

### 不负责

- 不代替 `TESTER` 执行具体测试用例
- 不代替 `AUTO-TESTER` 写脚本
- 不代替 `PERF-TESTER` 跑压测
- 不绕过文件协议下任务

## TESTER

### 负责

- 接收 `LEAD-QA` 派发的功能/验收测试任务
- 设计测试用例,执行手工测试
- 做主流程回归、边界测试、异常测试
- 记录缺陷,给出"通过/不通过/部分通过"结论

### 不负责

- 不自行决定质量是否达标
- 不把缺陷直接反馈给开发方(走 `LEAD-QA` 中转)
- 不承担自动化与性能测试

## AUTO-TESTER

### 负责

- 接收 `LEAD-QA` 派发的自动化测试任务
- 设计、编写、维护自动化测试脚本(UI/API/集成)
- 持续运行自动化套件,输出通过率与稳定性报告
- 标注不稳定用例与误报

### 不负责

- 不自行决定哪些用例进自动化(由 `LEAD-QA` 裁决)
- 不把脚本问题直接找开发方解决(走 `LEAD-QA` 中转)
- 不承担手工功能测试与性能测试

## PERF-TESTER

### 负责

- 接收 `LEAD-QA` 派发的性能测试任务
- 设计压测场景、负载模型、性能指标
- 执行压测,收集指标,分析瓶颈
- 输出性能报告与优化建议

### 不负责

- 不自行定义性能目标(由 `LEAD-QA` 与 `ADMIN` 商定)
- 不直接要求开发方改性能代码(走 `LEAD-QA` 中转)
- 不承担功能测试与自动化脚本工作

## 角色边界原则

1. `LEAD-QA` 管调度、对外接口和"是否建议发布"的决策。
2. `TESTER / AUTO-TESTER / PERF-TESTER` 只从 `LEAD-QA` 接任务、只向 `LEAD-QA` 回执。
3. 三条测试战线**可以并行推进**,但彼此之间不横向直接协作——必经 `LEAD-QA` 协调。
4. 任何正式任务和结论都必须落文件。
5. 发现跨边界问题(如自动化脚本失败需要手工复现),不越权处理,先回到 `LEAD-QA` 重新拆分。

---

## 协议演进说明（v1.0 ~ v1.4）

| 版本 | 变更 | 影响角色 |
|---|---|---|
| v1.0 | REVIEW envelope：高风险任务生成 `REVIEW-*.md`，需 ADMIN 批准 | leader / 全部 |
| v1.1 | `risk_level` 字段：`low / medium / high`；`needs_human` 自动触发人工审批 | leader 派单时设置 |
| v1.3 | `fcop_audit()`：协议体检工具，生成 `INSPECTION-*.md` 报告 | leader / ADMIN |
| v1.3 | GAL（治理告警层）：`fcop_create_alert` / `fcop_list_alerts` | leader |
| v1.4 | `supersedes:` 字段：文件级修正链（区别于 `parent:` 派生）| 全部 |
| v1.4 | write-side 工具须显式绑定项目路径（`set_project_dir()`）| MCP Server 层 |

> leader 角色的详细工具速查见对应 `roles/` 文件。
